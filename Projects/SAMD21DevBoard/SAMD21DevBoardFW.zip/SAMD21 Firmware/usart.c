/*- Includes ----------------------------------------------------------------*/
#include "usart.h"

/*- Definitions -------------------------------------------------------------*/

/*- Types -------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/

uint8_t usart_recv_buf[2 * USB_BUFFER_SIZE];
uint8_t usart_buf_idx;

/*- Implementations ---------------------------------------------------------*/

//-----------------------------------------------------------------------------
void usart_init(uint32_t baudRate)
{
    // Enable APB Clock for SERCOM0 (disabled by default on reset).
    REG_PM_APBCMASK |= PM_APBCMASK_SERCOM0;

    // Connect the clock source of SERCOM0 to the generic clock generator 0.
    GCLK->CLKCTRL.reg =
        GCLK_CLKCTRL_ID(SERCOM0_GCLK_ID_CORE) |
        GCLK_CLKCTRL_CLKEN |
        GCLK_CLKCTRL_GEN(0);

    // Wait for the synchronization of registers between clock domains to be complete.
    while (GCLK->STATUS.bit.SYNCBUSY == 1);

    // PA8 is PAD0 (TX)
    PORT->Group[0].DIRSET.reg = (1 << 8);
    PORT->Group[0].PINCFG[8].reg |= PORT_PINCFG_PMUXEN;
    PORT->Group[0].PMUX[8 >> 1].bit.PMUXE = PORT_PMUX_PMUXE_C_Val;

    // PA6 is PAD2 (RX)
    PORT->Group[0].DIRCLR.reg = (1 << 6);
    PORT->Group[0].PINCFG[6].reg &= ~PORT_PINCFG_PULLEN;
    PORT->Group[0].PINCFG[6].reg |= PORT_PINCFG_PMUXEN;
    PORT->Group[0].PMUX[6 >> 1].bit.PMUXE = PORT_PMUX_PMUXE_D_Val;

    SERCOM0->USART.CTRLA.reg = 
        SERCOM_USART_CTRLA_DORD |
        SERCOM_USART_CTRLA_MODE_USART_INT_CLK |
        SERCOM_USART_CTRLA_RXPO(2) |
        SERCOM_USART_CTRLA_TXPO(0);

    SERCOM0->USART.CTRLB.reg =
        SERCOM_USART_CTRLB_RXEN |
        SERCOM_USART_CTRLB_TXEN |
        SERCOM_USART_CTRLB_CHSIZE(0);

    usart_set_baud(baudRate);

    SERCOM0->USART.INTENSET.reg |= SERCOM_USART_INTENSET_RXC;
    NVIC_EnableIRQ(SERCOM0_IRQn);

    SERCOM0->USART.CTRLA.reg |= SERCOM_USART_CTRLA_ENABLE;
}

//-----------------------------------------------------------------------------
void usart_set_baud(uint32_t baud_rate)
{
    uint32_t baud_reg = (uint32_t)((float)(65536.0 * (1.0 - (16.0 * ((float)baud_rate / (float)F_CPU)))));
    SERCOM0->USART.BAUD.reg = baud_reg;
}

//-----------------------------------------------------------------------------
void irq_handler_sercom0(void)
{
    if (SERCOM0->USART.INTFLAG.bit.RXC)
    {
        // Write 1 to clear interrupt flag.
        SERCOM0->USART.INTFLAG.bit.RXC = 1;

        // Fill the lower half of the buffer with data incoming from the USART.
        usart_recv_buf[usart_buf_idx++] = REG_SERCOM0_USART_DATA;

        // If buffer is about to overflow, force a transmit operation (independent
        // of TC3 operation).
        if (usart_buf_idx == USB_BUFFER_SIZE)
        {
            usb_send_usart_packet();
        }
    }

    // PORT->Group[1].OUTTGL.reg = 0b01;
}