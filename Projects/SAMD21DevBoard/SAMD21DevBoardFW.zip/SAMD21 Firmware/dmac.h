/*- Guard -------------------------------------------------------------------*/
#ifndef _DMAC_H_
#define _DMAC_H_

/*- Includes ----------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdalign.h>

#include "samd21.h"

/*- Definitions -------------------------------------------------------------*/
#define DMAC_CH_USED      1
#define DMAC_CH_USART_TX  0

/*- Types -------------------------------------------------------------------*/
typedef struct
{
    uint16_t btctrl;
    uint16_t btcnt;
    uint32_t srcaddr;
    uint32_t dstaddr;
    uint32_t descaddr;
} dmaDescriptor_t;

/*- Macros ------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/

/*- Prototypes --------------------------------------------------------------*/
void dmac_init(void);

void dmac_usart_tx(uint8_t *data, uint8_t len);

#endif // _DMAC_H_
