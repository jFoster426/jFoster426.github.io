/*- Includes ----------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdalign.h>

#include "samd21.h"

#include "dap_config.h"
#include "dap.h"
#include "dmac.h"
#include "hal_gpio.h"
#include "nvm_data.h"
#include "tc3.h"
#include "usart.h"
#include "usb_descriptors.h"
#include "usb.h"
#include "util.h"

/*- Definitions -------------------------------------------------------------*/

/*- Types -------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/

/*- Implementations ---------------------------------------------------------*/

//-----------------------------------------------------------------------------
int main(void)
{
    dap_init();
    usart_init(115200);
    usb_init();
    tc3_init();
    dmac_init();

    PORT->Group[1].DIRSET.reg = (1 << 15) | (1 << 16) | (1 << 17); // SAMD21 status LEDs
    PORT->Group[1].OUTSET.reg = (1 << 15) | (1 << 16) | (1 << 17);

    PORT->Group[0].DIRSET.reg = (1 << 11); // SAME70 enable
    PORT->Group[0].OUTSET.reg = (1 << 11);

    while (1);

    return 0;
}
