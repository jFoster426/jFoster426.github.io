/*- Guard -------------------------------------------------------------------*/
#ifndef _DAP_H_
#define _DAP_H_

/*- Includes ----------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdalign.h>

#include "samd21.h"

#include "dap_config.h"

/*- Definitions -------------------------------------------------------------*/

/*- Types -------------------------------------------------------------------*/

/*- Macros ------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/

/*- Prototypes --------------------------------------------------------------*/
void dap_init(void);
uint8_t dap_req_get_byte(void);
uint16_t dap_req_get_half(void);
uint32_t dap_req_get_word(void);
void dap_resp_add_byte(uint8_t value);
void dap_resp_add_word(uint32_t value);
void dap_resp_set_byte(int index, uint8_t value);
bool dap_is_buf_error(void);
bool dap_filter_request(uint8_t *req);
int dap_process_request(uint8_t *req, int req_size, uint8_t *resp, int resp_size);
void dap_clock_test(int delay);

#endif // _DAP_H_
