/*- Includes ----------------------------------------------------------------*/
#include "adc.h"

/*- Definitions -------------------------------------------------------------*/
/*- Types -------------------------------------------------------------------*/
/*- Constants ---------------------------------------------------------------*/
/*- Variables ---------------------------------------------------------------*/
/*- Implementations ---------------------------------------------------------*/

//-----------------------------------------------------------------------------
void adc_init(void)
{
    // Enable APB Clock for ADC (disabled by default on reset).
    REG_PM_APBCMASK |= PM_APBCMASK_ADC;

    // Connect the clock source of ADC to the generic clock generator 0.
    GCLK->CLKCTRL.reg =
        GCLK_CLKCTRL_ID(ADC_GCLK_ID) |
        GCLK_CLKCTRL_CLKEN |
        GCLK_CLKCTRL_GEN(0);

    // Wait for the synchronization of registers between clock domains to be complete.
    while (GCLK->STATUS.bit.SYNCBUSY == 1);

    // Perform a sofware reset to set all of the registers to their default values.
    ADC->CTRLA.bit.SWRST = 1;

    // Set the reference for the ADC to use the internal 1.0V reference
    // (derived from the 1.1V internal bandgap reference).
    ADC->REFCTRL.bit.REFCOMP = 1;
    ADC->REFCTRL.bit.REFSEL = ADC_REFCTRL_REFSEL_INT1V_Val;

    // Configure the desired number of averages.
    uint16_t averages = 32;
    ADC->AVGCTRL.bit.ADJRES = averages;
    ADC->AVGCTRL.bit.SAMPLENUM = averages;

    // Sampling time = (sample_n + 1) * (CLK_ADC / 2)
    // where 0 < sample_n < 63.
    // ADC_CLK defaults to the peripheral clock / 4.
    uint8_t sample_n = 100;
    ADC->SAMPCTRL.reg = sample_n;

    // Select negative reference and positive input
    // for the converter.
    ADC->INPUTCTRL.bit.MUXNEG = ADC_INPUTCTRL_MUXNEG_IOGND_Val;
    ch_idx = 0;
    ADC->INPUTCTRL.bit.MUXPOS = adc_pins[ch_idx];


    // Clear any pending interrupts.
    ADC->INTENSET.bit.RESRDY = 1;

    // Enable interrupts.
    ADC->INTFLAG.bit.RESRDY = 1;
    NVIC_EnableIRQ(ADC_IRQn);

    // Enable the ADC module.
    ADC->CTRLA.bit.ENABLE = 1;

    // Start the first conversion.
    ADC->SWTRIG.bit.START = 1;
}

//-----------------------------------------------------------------------------
void irq_handler_adc(void)
{
    // Store the result from the previously completed conversion.
    adc_res[ch_idx] = ADC->RESULT.reg;

    ch_idx++;
    if (ch_idx >= NUM_ADC_PINS)
    {
        ch_idx = 0;
    }

    // Set the next channel to convert.
    ADC->INPUTCTRL.bit.MUXPOS = adc_pins[ch_idx];

    // Clear the interrupt.
    ADC->INTENSET.bit.RESRDY = 1;

    // Start the next conversion.
    ADC->SWTRIG.bit.START = 1;
}
