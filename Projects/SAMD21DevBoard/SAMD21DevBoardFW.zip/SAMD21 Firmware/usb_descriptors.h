/*- Guard -------------------------------------------------------------------*/
#ifndef _USB_DESCRIPTORS_H_
#define _USB_DESCRIPTORS_H_

/*- Includes ----------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdalign.h>

#include "samd21.h"

#include "util.h"

/*- Definitions -------------------------------------------------------------*/
enum
{
  USB_HID_DESCRIPTOR          = 0x21,
  USB_HID_REPORT_DESCRIPTOR   = 0x22,
  USB_HID_PHYSICAL_DESCRIPTOR = 0x23,
};

enum
{
  USB_STR_ZERO,
  USB_STR_MANUFACTURER,
  USB_STR_PRODUCT,
  USB_STR_SERIAL_NUMBER,
  USB_STR_CONFIGURATION,
  USB_STR_HID_INTERFACE,
  USB_STR_CDC_COMM_INTERFACE,
  USB_STR_CDC_DATA_INTERFACE,
  USB_STR_COUNT,
};

enum
{
    USB_CDC_EP_COMM = 3,
    USB_CDC_EP_SEND = 4,
    USB_CDC_EP_RECV = 5,
};

enum
{
  USB_DEVICE_EPCFG_EPTYPE_DISABLED    = 0,
  USB_DEVICE_EPCFG_EPTYPE_CONTROL     = 1,
  USB_DEVICE_EPCFG_EPTYPE_ISOCHRONOUS = 2,
  USB_DEVICE_EPCFG_EPTYPE_BULK        = 3,
  USB_DEVICE_EPCFG_EPTYPE_INTERRUPT   = 4,
  USB_DEVICE_EPCFG_EPTYPE_DUAL_BANK   = 5,
};

enum
{
  USB_DEVICE_PCKSIZE_SIZE_8    = 0,
  USB_DEVICE_PCKSIZE_SIZE_16   = 1,
  USB_DEVICE_PCKSIZE_SIZE_32   = 2,
  USB_DEVICE_PCKSIZE_SIZE_64   = 3,
  USB_DEVICE_PCKSIZE_SIZE_128  = 4,
  USB_DEVICE_PCKSIZE_SIZE_256  = 5,
  USB_DEVICE_PCKSIZE_SIZE_512  = 6,
  USB_DEVICE_PCKSIZE_SIZE_1023 = 7,
};

enum
{
  USB_GET_STATUS        = 0,
  USB_CLEAR_FEATURE     = 1,
  USB_SET_FEATURE       = 3,
  USB_SET_ADDRESS       = 5,
  USB_GET_DESCRIPTOR    = 6,
  USB_SET_DESCRIPTOR    = 7,
  USB_GET_CONFIGURATION = 8,
  USB_SET_CONFIGURATION = 9,
  USB_GET_INTERFACE     = 10,
  USB_SET_INTERFACE     = 11,
  USB_SYNCH_FRAME       = 12,
};

enum
{
  USB_DEVICE_DESCRIPTOR                    = 1,
  USB_CONFIGURATION_DESCRIPTOR             = 2,
  USB_STRING_DESCRIPTOR                    = 3,
  USB_INTERFACE_DESCRIPTOR                 = 4,
  USB_ENDPOINT_DESCRIPTOR                  = 5,
  USB_DEVICE_QUALIFIER_DESCRIPTOR          = 6,
  USB_OTHER_SPEED_CONFIGURATION_DESCRIPTOR = 7,
  USB_INTERFACE_POWER_DESCRIPTOR           = 8,
  USB_OTG_DESCRIPTOR                       = 9,
  USB_DEBUG_DESCRIPTOR                     = 10,
  USB_INTERFACE_ASSOCIATION_DESCRIPTOR     = 11,
  USB_BINARY_OBJECT_STORE_DESCRIPTOR       = 15,
  USB_DEVICE_CAPABILITY_DESCRIPTOR         = 16,
  USB_CS_INTERFACE_DESCRIPTOR              = 36,
};

enum
{
  USB_DEVICE_RECIPIENT     = 0,
  USB_INTERFACE_RECIPIENT  = 1,
  USB_ENDPOINT_RECIPIENT   = 2,
  USB_OTHER_RECIPIENT      = 3,
};

enum
{
  USB_STANDARD_REQUEST     = 0,
  USB_CLASS_REQUEST        = 1,
  USB_VENDOR_REQUEST       = 2,
};

enum
{
  USB_OUT_TRANSFER         = 0,
  USB_IN_TRANSFER          = 1,
};

enum
{
  USB_IN_ENDPOINT          = 0x80,
  USB_OUT_ENDPOINT         = 0x00,
  USB_INDEX_MASK           = 0x7f,
  USB_DIRECTION_MASK       = 0x80,
};

enum
{
  USB_CONTROL_ENDPOINT     = 0 << 0,
  USB_ISOCHRONOUS_ENDPOINT = 1 << 0,
  USB_BULK_ENDPOINT        = 2 << 0,
  USB_INTERRUPT_ENDPOINT   = 3 << 0,

  USB_NO_SYNCHRONIZATION   = 0 << 2,
  USB_ASYNCHRONOUS         = 1 << 2,
  USB_ADAPTIVE             = 2 << 2,
  USB_SYNCHRONOUS          = 3 << 2,

  USB_DATA_ENDPOINT        = 0 << 4,
  USB_FEEDBACK_ENDPOINT    = 1 << 4,
  USB_IMP_FB_DATA_ENDPOINT = 2 << 4,
};

enum
{
  USB_CDC_SEND_ENCAPSULATED_COMMAND = 0x00,
  USB_CDC_GET_ENCAPSULATED_RESPONSE = 0x01,
  USB_CDC_SET_COMM_FEATURE          = 0x02,
  USB_CDC_GET_COMM_FEATURE          = 0x03,
  USB_CDC_CLEAR_COMM_FEATURE        = 0x04,
  USB_CDC_SET_AUX_LINE_STATE        = 0x10,
  USB_CDC_SET_HOOK_STATE            = 0x11,
  USB_CDC_PULSE_SETUP               = 0x12,
  USB_CDC_SEND_PULSE                = 0x13,
  USB_CDC_SET_PULSE_TIME            = 0x14,
  USB_CDC_RING_AUX_JACK             = 0x15,
  USB_CDC_SET_LINE_CODING           = 0x20,
  USB_CDC_GET_LINE_CODING           = 0x21,
  USB_CDC_SET_CONTROL_LINE_STATE    = 0x22,
  USB_CDC_SEND_BREAK                = 0x23,
  USB_CDC_SET_RINGER_PARMS          = 0x30,
  USB_CDC_GET_RINGER_PARMS          = 0x31,
  USB_CDC_SET_OPERATION_PARMS       = 0x32,
  USB_CDC_GET_OPERATION_PARMS       = 0x33,
  USB_CDC_SET_LINE_PARMS            = 0x34,
  USB_CDC_GET_LINE_PARMS            = 0x35,
  USB_CDC_DIAL_DIGITS               = 0x36,
  USB_CDC_SET_UNIT_PARAMETER        = 0x37,
  USB_CDC_GET_UNIT_PARAMETER        = 0x38,
  USB_CDC_CLEAR_UNIT_PARAMETER      = 0x39,
  USB_CDC_GET_PROFILE               = 0x3a,

  USB_CDC_NOTIFY_RING_DETECT        = 0x09,
  USB_CDC_NOTIFY_SERIAL_STATE       = 0x20,
  USB_CDC_NOTIFY_CALL_STATE_CHANGE  = 0x28,
  USB_CDC_NOTIFY_LINE_STATE_CHANGE  = 0x29,
};

enum
{
  USB_CDC_1_STOP_BIT    = 0,
  USB_CDC_1_5_STOP_BITS = 1,
  USB_CDC_2_STOP_BITS   = 2,
};

enum
{
  USB_CDC_NO_PARITY     = 0,
  USB_CDC_ODD_PARITY    = 1,
  USB_CDC_EVEN_PARITY   = 2,
  USB_CDC_MARK_PARITY   = 3,
  USB_CDC_SPACE_PARITY  = 4,
};

enum
{
  USB_CDC_5_DATA_BITS   = 5,
  USB_CDC_6_DATA_BITS   = 6,
  USB_CDC_7_DATA_BITS   = 7,
  USB_CDC_8_DATA_BITS   = 8,
  USB_CDC_16_DATA_BITS  = 16,
};

enum
{
  USB_CDC_DEVICE_CLASS  = 2,  // USB Communication Device Class
  USB_CDC_COMM_CLASS    = 2,  // CDC Communication Class Interface
  USB_CDC_DATA_CLASS    = 10, // CDC Data Class Interface
};

enum
{
  USB_CDC_DLCM_SUBCLASS = 1, // Direct Line Control Model
  USB_CDC_ACM_SUBCLASS  = 2, // Abstract Control Model
  USB_CDC_TCM_SUBCLASS  = 3, // Telephone Control Model
  USB_CDC_MCCM_SUBCLASS = 4, // Multi-Channel Control Model
  USB_CDC_CCM_SUBCLASS  = 5, // CAPI Control Model
  USB_CDC_ETH_SUBCLASS  = 6, // Ethernet Networking Control Model
  USB_CDC_ATM_SUBCLASS  = 7, // ATM Networking Control Model
};

enum
{
  USB_CDC_HEADER_SUBTYPE    = 0, // Header Functional Descriptor
  USB_CDC_CALL_MGMT_SUBTYPE = 1, // Call Management
  USB_CDC_ACM_SUBTYPE       = 2, // Abstract Control Management
  USB_CDC_UNION_SUBTYPE     = 6, // Union Functional Descriptor
};

// USB CDC Call Management Capabilities
enum
{
  USB_CDC_CALL_MGMT_SUPPORTED = (1 << 0),
  USB_CDC_CALL_MGMT_OVER_DCI  = (1 << 1),
};

// USB CDC ACM Capabilities
enum
{
  // Device supports the request combination of Set_Comm_Feature,
  // Clear_Comm_Feature, and Get_Comm_Feature.
  USB_CDC_ACM_SUPPORT_FEATURE_REQUESTS   = (1 << 0),

  // Device supports the request combination of Set_Line_Coding, Set_Control_Line_State,
  // Get_Line_Coding, and the notification Serial_State.
  USB_CDC_ACM_SUPPORT_LINE_REQUESTS      = (1 << 1),

  // Device supports the request Send_Break.
  USB_CDC_ACM_SUPPORT_SENDBREAK_REQUESTS = (1 << 2),

  // Device supports the notification Network_Connection.
  USB_CDC_ACM_SUPPORT_NOTIFY_REQUESTS    = (1 << 3),
};

enum
{
  USB_CDC_CTRL_SIGNAL_DTE_PRESENT        = (1 << 0), // DTR
  USB_CDC_CTRL_SIGNAL_ACTIVATE_CARRIER   = (1 << 1), // RTS
};

enum
{
  USB_CDC_SERIAL_STATE_DCD     = (1 << 0),
  USB_CDC_SERIAL_STATE_DSR     = (1 << 1),
  USB_CDC_SERIAL_STATE_BREAK   = (1 << 2),
  USB_CDC_SERIAL_STATE_RING    = (1 << 3),
  USB_CDC_SERIAL_STATE_FRAMING = (1 << 4),
  USB_CDC_SERIAL_STATE_PARITY  = (1 << 5),
  USB_CDC_SERIAL_STATE_OVERRUN = (1 << 6),
};

/*- Types -------------------------------------------------------------------*/
typedef struct PACK
{
  uint8_t   bLength;
  uint8_t   bDescriptorType;
  uint16_t  bcdHID;
  uint8_t   bCountryCode;
  uint8_t   bNumDescriptors;
  uint8_t   bDescriptorType1;
  uint16_t  wDescriptorLength;
} usb_hid_descriptor_t;

typedef struct PACK
{
  uint8_t   bLength;
  uint8_t   bDescriptorType;
  uint16_t  bcdUSB;
  uint8_t   bDeviceClass;
  uint8_t   bDeviceSubClass;
  uint8_t   bDeviceProtocol;
  uint8_t   bMaxPacketSize0;
  uint16_t  idVendor;
  uint16_t  idProduct;
  uint16_t  bcdDevice;
  uint8_t   iManufacturer;
  uint8_t   iProduct;
  uint8_t   iSerialNumber;
  uint8_t   bNumConfigurations;
} usb_device_descriptor_t;

typedef struct usb_device_qualifier_descriptor {
  uint8_t   bLength;
  uint8_t   bDescriptorType;
  uint16_t  bcdUSB;
  uint8_t   bDeviceClass;
  uint8_t   bDeviceSubClass;
  uint8_t   bDeviceProtocol;
  uint8_t   bMaxPacketSize0;
  uint8_t   bNumConfigurations;
  uint8_t   bReserved;
} usb_device_qualifier_descriptor_t;

typedef struct usb_iad_descriptor {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t bFirstInterface;
    uint8_t bInterfaceCount;
    uint8_t bFunctionClass;
    uint8_t bFunctionSubClass;
    uint8_t bFunctionProtocol;
    uint8_t iFunction;
} usb_iad_descriptor_t;

typedef struct PACK
{
  uint8_t   bLength;
  uint8_t   bDescriptorType;
  uint16_t  wTotalLength;
  uint8_t   bNumInterfaces;
  uint8_t   bConfigurationValue;
  uint8_t   iConfiguration;
  uint8_t   bmAttributes;
  uint8_t   bMaxPower;
} usb_configuration_descriptor_t;

typedef struct PACK
{
  uint8_t   bLength;
  uint8_t   bDescriptorType;
  uint8_t   bInterfaceNumber;
  uint8_t   bAlternateSetting;
  uint8_t   bNumEndpoints;
  uint8_t   bInterfaceClass;
  uint8_t   bInterfaceSubClass;
  uint8_t   bInterfaceProtocol;
  uint8_t   iInterface;
} usb_interface_descriptor_t;

typedef struct PACK
{
  uint8_t   bLength;
  uint8_t   bDescriptorType;
  uint8_t   bEndpointAddress;
  uint8_t   bmAttributes;
  uint16_t  wMaxPacketSize;
  uint8_t   bInterval;
} usb_endpoint_descriptor_t;

typedef struct PACK
{
  uint8_t   bLength;
  uint8_t   bDescriptorType;
  uint16_t  wLANGID;
} usb_string_descriptor_zero_t;

typedef struct PACK
{
  uint8_t   bLength;
  uint8_t   bDescriptorType;
  uint16_t  bString;
} usb_string_descriptor_t;

typedef struct PACK
{
  uint8_t   bLength;
  uint8_t   bDescriptorType;
} usb_descriptor_header_t;

typedef struct PACK
{
  uint8_t   bFunctionalLength;
  uint8_t   bDescriptorType;
  uint8_t   bDescriptorSubtype;
  uint16_t  bcdCDC;
} usb_cdc_header_functional_descriptor_t;

typedef struct PACK
{
  uint8_t   bFunctionalLength;
  uint8_t   bDescriptorType;
  uint8_t   bDescriptorSubtype;
  uint8_t   bmCapabilities;
} usb_cdc_abstract_control_managment_descriptor_t;

typedef struct PACK
{
  uint8_t   bFunctionalLength;
  uint8_t   bDescriptorType;
  uint8_t   bDescriptorSubtype;
  uint8_t   bmCapabilities;
  uint8_t   bDataInterface;
} usb_cdc_call_managment_functional_descriptor_t;

typedef struct PACK
{
  uint8_t   bFunctionalLength;
  uint8_t   bDescriptorType;
  uint8_t   bDescriptorSubtype;
  uint8_t   bMasterInterface;
  uint8_t   bSlaveInterface0;
} usb_cdc_union_functional_descriptor_t;

typedef struct PACK
{
    usb_configuration_descriptor_t                    configuration;
    usb_interface_descriptor_t                        interface;
    usb_hid_descriptor_t                              hid;
    usb_endpoint_descriptor_t                         ep_in;
    usb_endpoint_descriptor_t                         ep_out;
    usb_iad_descriptor_t                              comm_iad;
    usb_interface_descriptor_t                        interface_comm;
    usb_cdc_header_functional_descriptor_t            cdc_header;
    usb_cdc_abstract_control_managment_descriptor_t   cdc_acm;
    usb_cdc_union_functional_descriptor_t             cdc_union;
    usb_cdc_call_managment_functional_descriptor_t    cdc_call_mgmt;
    usb_endpoint_descriptor_t                         ep_comm;
    usb_interface_descriptor_t                        interface_data;
    usb_endpoint_descriptor_t                         ep_in_cdc;
    usb_endpoint_descriptor_t                         ep_out_cdc;
} usb_configuration_hierarchy_t;

/*- Macros ------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/
extern const usb_device_descriptor_t usb_device_descriptor;
extern const usb_device_qualifier_descriptor_t usb_device_qualifier_descriptor;
extern const usb_configuration_hierarchy_t usb_configuration_hierarchy;
extern const uint8_t usb_hid_report_descriptor[28];
extern const usb_string_descriptor_zero_t usb_string_descriptor_zero;
extern const char *const usb_strings[];

/*- Variables ---------------------------------------------------------------*/

/*- Prototypes --------------------------------------------------------------*/

#endif // _USB_DESCRIPTORS_H_
