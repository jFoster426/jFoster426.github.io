/*- Includes ----------------------------------------------------------------*/
#include "tc3.h"

/*- Definitions -------------------------------------------------------------*/

/*- Types -------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/

/*- Prototypes --------------------------------------------------------------*/

/*- Implementations ---------------------------------------------------------*/

//-----------------------------------------------------------------------------
void tc3_init(void)
{
    // Enable APB Clock for TC3 (disabled by default on reset).
    REG_PM_APBCMASK |= PM_APBCMASK_TC3;

    // Connect the clock source of TC3 to the generic clock generator 0.
    GCLK->CLKCTRL.reg =
        GCLK_CLKCTRL_ID(TC3_GCLK_ID) |
        GCLK_CLKCTRL_CLKEN |
        GCLK_CLKCTRL_GEN(0);

    // Wait for the synchronization of registers between clock domains to be complete.
    while (GCLK->STATUS.bit.SYNCBUSY == 1);

    // Reset the peripheral and wait for the operation to complete.
    TC3->COUNT16.CTRLA.bit.SWRST = 1;
    while (TC3->COUNT16.CTRLA.bit.SWRST == 1);

    TC3->COUNT16.CTRLA.reg =
        TC_CTRLA_PRESCALER_DIV1024 |
        TC_CTRLA_WAVEGEN_MFRQ |
        TC_CTRLA_MODE_COUNT16 |
        TC_CTRLA_ENABLE;

    uint16_t trig_freq = 1000; // 1000Hz trigger frequency.
    TC3->COUNT16.CC[0].reg = (uint16_t)((48000000UL / 1024) / trig_freq);

    TC3->COUNT16.INTENSET.bit.MC0 = 1;

    NVIC_EnableIRQ(TC3_IRQn);
}

//-----------------------------------------------------------------------------
void irq_handler_tc3(void)
{
    if (TC3->COUNT16.INTFLAG.bit.MC0)
    {
        // Write 1 to clear interrupt flag.
        TC3->COUNT16.INTFLAG.bit.MC0 = 1;

        // Call a separate function because the SERCOM0 interrupt may need access to it
        // as well.
        usb_send_usart_packet();
    }
}