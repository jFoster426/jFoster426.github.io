/*- Includes ----------------------------------------------------------------*/
#include "dmac.h"

/*- Definitions -------------------------------------------------------------*/

/*- Types -------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/
volatile dmaDescriptor_t dmaDescriptorArrayHead[DMAC_CH_USED] __attribute__ ((aligned (16)));
dmaDescriptor_t dmaDescriptorWritebackArray[DMAC_CH_USED] __attribute__ ((aligned (16)));

/*- Implementations ---------------------------------------------------------*/

//-----------------------------------------------------------------------------
void dmac_init(void)
{
    PM->AHBMASK.bit.DMAC_ = 1;
    PM->APBBMASK.bit.DMAC_ = 1;

    // DMAC->CTRL.bit.DMAENABLE = 0;
    DMAC->CTRL.bit.SWRST = 1;
    while (DMAC->CTRL.bit.SWRST == 1);

    dmaDescriptorArrayHead[DMAC_CH_USART_TX].btctrl = 0;
    // dmaDescriptorArrayHead[DMAC_CH_USART_TX].btcnt = 0;
    dmaDescriptorArrayHead[DMAC_CH_USART_TX].descaddr = 0;

    // Prevent write-back address from being initialized to 0. This will allow us to see if the DMA has started the transfer or not
    // (if started, the write-back address will be over-written with something else).
    dmaDescriptorWritebackArray[DMAC_CH_USART_TX].descaddr = 0;

    DMAC->BASEADDR.reg = (uint32_t)dmaDescriptorArrayHead;
    DMAC->WRBADDR.reg = (uint32_t)dmaDescriptorWritebackArray;

    DMAC->CTRL.reg = DMAC_CTRL_DMAENABLE | DMAC_CTRL_LVLEN(0xF);
    NVIC_EnableIRQ(DMAC_IRQn);

    DMAC->CHID.reg = DMAC_CH_USART_TX;

    DMAC->CHCTRLA.bit.ENABLE = 0;
    DMAC->CHCTRLA.bit.SWRST = 1;
    while (DMAC->CHCTRLA.bit.SWRST == 1);

    DMAC->CHCTRLB.reg = DMAC_CHCTRLB_LVL(0) | DMAC_CHCTRLB_TRIGSRC(SERCOM0_DMAC_ID_TX) | DMAC_CHCTRLB_TRIGACT_BEAT;
    DMAC->CHINTENSET.reg = DMAC_CHINTENSET_TCMPL | DMAC_CHINTENSET_SUSP | DMAC_CHINTENSET_TERR;

    DMAC->CHCTRLA.bit.ENABLE = 1;
}

//-----------------------------------------------------------------------------
void dmac_usart_tx(uint8_t *data, uint8_t len)
{
    // Traverse to the tail of the list.
    volatile dmaDescriptor_t *tail = &dmaDescriptorArrayHead[DMAC_CH_USART_TX];
    while (tail->descaddr != 0) tail = (dmaDescriptor_t *)(tail->descaddr);

    // Allocate memory for source data and copy from function argument.
    uint8_t *srcData = (uint8_t *)malloc(len);
    memcpy(srcData, data, len);

    // Initialize temporary descriptor which is then copied to tail when ready.
    dmaDescriptor_t newDescriptor;
    newDescriptor.btctrl = DMAC_BTCTRL_BLOCKACT_NOACT | DMAC_BTCTRL_BEATSIZE_BYTE | DMAC_BTCTRL_VALID | DMAC_BTCTRL_SRCINC;
    newDescriptor.btcnt = len;
    newDescriptor.dstaddr = (uint32_t)(&REG_SERCOM0_USART_DATA);
    newDescriptor.srcaddr = (uint32_t)(srcData + len);
    newDescriptor.descaddr = 0;

    // If tail points to head (list is only one element long) and head descriptor is not valid, then it can be overwritten.
    if (tail == &dmaDescriptorArrayHead[DMAC_CH_USART_TX] && !(tail->btctrl & DMAC_BTCTRL_VALID))
    {
        // Copy the new descriptor information into the list head.
        memcpy(&dmaDescriptorArrayHead[DMAC_CH_USART_TX], &newDescriptor, sizeof(dmaDescriptor_t));
    }
    else
    {
        // Allocate required memory for the new descriptor, point tail to it.
        tail->descaddr = (dmaDescriptor_t *)malloc(sizeof(dmaDescriptor_t));

        // Copy newDescriptor into tail.
        memcpy((uint32_t *)(tail->descaddr), &newDescriptor, sizeof(dmaDescriptor_t));

        // We need to add a descriptor to the end of the list.
        // Follow procedure in 20.6.3.1.2 in SAMD21 datasheet.
        if (dmaDescriptorWritebackArray->descaddr == 0)
        {
            // The DMA is executing the same descriptor as the one which requires changes.
            // (This would always be the last descriptor in the list, so its descaddr will
            // always be 0).
            DMAC->CHCTRLB.bit.CMD = DMAC_CHCTRLB_CMD_SUSPEND_Val;

            // Once the DMA finishes the current block transfer, point it to start
            // transferring the descriptor that was just added.
            dmaDescriptorWritebackArray->descaddr = tail->descaddr;

            // Send the resume command to start the transfer.
            DMAC->CHCTRLB.bit.CMD = DMAC_CHCTRLB_CMD_RESUME_Val;
        }
    }
    // If the bus was disabled (the previous transfer completed), re-enable the
    // DMA channel to start the transfer.
    DMAC->CHCTRLA.bit.ENABLE = 1;
}

//-----------------------------------------------------------------------------
void irq_handler_dmac()
{
    uint8_t intFlags = DMAC->CHINTFLAG.reg;
    
    // Must clear this flag! Otherwise the interrupt will be triggered over and over again.
    DMAC->CHINTFLAG.reg = DMAC_CHINTFLAG_MASK;

    if (intFlags & DMAC_CHINTFLAG_TCMPL)
    {
        // Iterate through the list of descriptors (if there is one or more than one) and
        // free all the memory that was created using malloc.
        // Ensure not to free the head of the list, since it was never allocated using malloc!
        free((dmaDescriptor_t *)(dmaDescriptorArrayHead[DMAC_CH_USART_TX].srcaddr - dmaDescriptorArrayHead[DMAC_CH_USART_TX].btcnt));

        // Loop through any remaining descriptors in the list.
        volatile dmaDescriptor_t *iter = (dmaDescriptor_t *)dmaDescriptorArrayHead[DMAC_CH_USART_TX].descaddr;
        while (iter != 0 && iter->btctrl & DMAC_BTCTRL_VALID)
        {
            volatile dmaDescriptor_t *tmp = iter;
            iter = (dmaDescriptor_t *)(iter->descaddr);

            // Free srcData pointer created in dmac_usart_tx() above.
            free((uint8_t *)(tmp->srcaddr - tmp->btcnt));

            // Free the descriptor itself.
            free((volatile dmaDescriptor_t *)(tmp));
        }

        // Make sure the list head indicates that the list length is reset to one, and that
        // the descriptor inside the list head is invalid. This forces the descriptor to be
        // overwritten on the next transfer.
        dmaDescriptorArrayHead[DMAC_CH_USART_TX].btctrl &= ~(DMAC_BTCTRL_VALID);
        dmaDescriptorArrayHead[DMAC_CH_USART_TX].descaddr = 0;
    }
}