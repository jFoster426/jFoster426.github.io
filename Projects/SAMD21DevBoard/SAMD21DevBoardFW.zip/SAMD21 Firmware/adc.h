/*- Guard -------------------------------------------------------------------*/
#ifndef _ADC_H_
#define _ADC_H_

/*- Includes ----------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdalign.h>

#include "samd21.h"

/*- Definitions -------------------------------------------------------------*/
#define NUM_ADC_PINS   1

/*- Types -------------------------------------------------------------------*/

/*- Macros ------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/
const uint8_t adc_pins[NUM_ADC_PINS] = 
{
    ADC_INPUTCTRL_MUXPOS_PIN0_Val
};

/*- Variables ---------------------------------------------------------------*/
uint16_t adc_res[NUM_ADC_PINS];
uint8_t ch_idx;

/*- Prototypes --------------------------------------------------------------*/
void adc_init(void);

#endif