/*- Guard -------------------------------------------------------------------*/
#ifndef _UTIL_H_
#define _UTIL_H_

/*- Includes ----------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdalign.h>

#include "samd21.h"

/*- Definitions -------------------------------------------------------------*/
#define PACK                    __attribute__((packed))

#define INLINE                  static inline __attribute__((always_inline))

#define USB_BUFFER_SIZE         64

/*- Types -------------------------------------------------------------------*/

/*- Macros ------------------------------------------------------------------*/
#define LIMIT(a, b)             (((a) > (b)) ? (b) : (a))

/*
// static uint8_t abc;
// static char def[256];
// #define DEBUG(...) \
//                     abc = 0; \
//                     sprintf(def, __VA_ARGS__); \
//                     while (def[abc] != '\0') \
//                     { \
//                         while (!(REG_SERCOM0_USART_INTFLAG) & 1); \
//                         REG_SERCOM0_USART_DATA = def[abc++]; \
//                         while (!(REG_SERCOM0_USART_INTFLAG) & 1); \
//                     }

// static uint32_t *ghi;
// static uint8_t jkl;
// #define DEBUG_MEM(adrl, len) \
//                     ghi = adrl; \
//                     jkl = 0; \
//                     while (jkl < len) \
//                     { \
//                         DEBUG("%08X, %08X\n", ghi, *ghi); \
//                         ghi++; \
//                         jkl++; \
//                     }
*/

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/

/*- Prototypes --------------------------------------------------------------*/

#endif // _UTIL_H_
