/*- Includes ----------------------------------------------------------------*/
#include "usb.h"

/*- Definitions -------------------------------------------------------------*/
#define USB_CMD(dir, rcpt, type, cmd) \
    ((USB_##cmd << 8) | (USB_##dir##_TRANSFER << 7) | (USB_##type##_REQUEST << 5) | (USB_##rcpt##_RECIPIENT << 0))

HAL_GPIO_PIN(USB_DM,   A, 24);
HAL_GPIO_PIN(USB_DP,   A, 25);

/*- Types -------------------------------------------------------------------*/
typedef struct
{
    void         (*callback)(void);
} usb_endpoint_bank_t;

typedef struct
{
    usb_endpoint_bank_t out;
    usb_endpoint_bank_t in;
} usb_endpoint_t;

typedef union
{
    UsbDeviceDescBank    bank[2];
    struct
    {
        UsbDeviceDescBank  out;
        UsbDeviceDescBank  in;
    };
} usb_mem_t;

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/
static usb_endpoint_t usb_endpoints[USB_EP_NUM];
static int usb_config;

// Configure default settings for the physical COM port.
static usb_cdc_line_coding_t usb_cdc_line_coding =
{
    .dwDTERate   = 115200,
    .bCharFormat = USB_CDC_1_STOP_BIT,
    .bParityType = USB_CDC_NO_PARITY,
    .bDataBits   = USB_CDC_8_DATA_BITS,
};

// static alignas(4) usb_cdc_notify_serial_state_t usb_cdc_notify_message;
static usb_mem_t usb_mem[USB_EP_NUM];
static uint32_t usb_ctrl_in_buf[USB_BUFFER_SIZE];
static uint32_t usb_ctrl_out_buf[USB_BUFFER_SIZE];

alignas(4) uint8_t app_request_buffer[DAP_CONFIG_PACKET_SIZE];
alignas(4) uint8_t app_response_buffer[DAP_CONFIG_PACKET_SIZE];

alignas(4) uint8_t usb_cdc_recv_buf[USB_BUFFER_SIZE];
alignas(4) uint8_t usb_cdc_send_buf[USB_BUFFER_SIZE];

/*- Implementations ---------------------------------------------------------*/

//-----------------------------------------------------------------------------
void usb_cdc_update_line_coding(void)
{
    uint8_t length = LIMIT(usb_mem[0].out.PCKSIZE.bit.BYTE_COUNT, 7);
    memcpy((uint8_t *)&usb_cdc_line_coding, (uint8_t *)&usb_ctrl_out_buf, length);
    // DEBUG("Port Settings:%d,%d,%d,%d\n", usb_cdc_line_coding.dwDTERate, usb_cdc_line_coding.bCharFormat, usb_cdc_line_coding.bParityType, usb_cdc_line_coding.bDataBits);

    usb_endpoints[0].out.callback = NULL;
    usb_control_send_zlp();
}

//-----------------------------------------------------------------------------
void usb_cdc_send_callback(void)
{
}

//-----------------------------------------------------------------------------
void usb_cdc_recv_callback(void)
{
    // Size of the data recevied.
    // Note that the first byte of received packet is stored in usb_cdc_recv_buf[0].
    uint16_t size = usb_mem[USB_CDC_EP_RECV].out.PCKSIZE.bit.BYTE_COUNT;

    // Send the data over the physical USART.
    dmac_usart_tx(usb_cdc_recv_buf, size);
    
    // Set up in advance what to do when the host wants to transfer the next round of data.
    // Set the callback function to this function.
    usb_recv(USB_CDC_EP_RECV, usb_cdc_recv_buf, sizeof(usb_cdc_recv_buf), usb_cdc_recv_callback);

    // PORT->Group[1].OUTTGL.reg = 0b10;
}

//-----------------------------------------------------------------------------
void usb_cdc_comm_callback(void)
{
}

//-----------------------------------------------------------------------------
void usb_hid_send_callback(void)
{
}

//-----------------------------------------------------------------------------
void usb_hid_recv_callback(void)
{
    dap_process_request(app_request_buffer, sizeof(app_request_buffer), app_response_buffer, sizeof(app_response_buffer));
    usb_send(APP_EP_SEND, app_response_buffer, sizeof(app_response_buffer), usb_hid_send_callback);
    usb_recv(APP_EP_RECV, app_request_buffer, sizeof(app_request_buffer), usb_hid_recv_callback);
}

//-----------------------------------------------------------------------------
void usb_configuration_callback(int config)
{
    // HID stuff
    usb_recv(APP_EP_RECV, app_request_buffer, sizeof(app_request_buffer), usb_hid_recv_callback);
    // CDC stuff
    usb_recv(USB_CDC_EP_RECV, usb_cdc_recv_buf, sizeof(usb_cdc_recv_buf), usb_cdc_recv_callback);
    usb_recv(USB_CDC_EP_COMM, usb_cdc_recv_buf, sizeof(usb_cdc_recv_buf), usb_cdc_comm_callback);

    (void)config;
}

//-----------------------------------------------------------------------------
void usb_init(void)
{
    usb_config = 0;

    HAL_GPIO_USB_DM_pmuxen(PORT_PMUX_PMUXE_G_Val);
    HAL_GPIO_USB_DP_pmuxen(PORT_PMUX_PMUXE_G_Val);

    PM->APBBMASK.reg |= PM_APBBMASK_USB;

    GCLK->CLKCTRL.reg = GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_ID(USB_GCLK_ID) | GCLK_CLKCTRL_GEN(0);

    USB->DEVICE.CTRLA.bit.SWRST = 1;
    while (USB->DEVICE.SYNCBUSY.bit.SWRST);

    USB->DEVICE.PADCAL.bit.TRANSN = NVM_READ_CAL(NVM_USB_TRANSN);
    USB->DEVICE.PADCAL.bit.TRANSP = NVM_READ_CAL(NVM_USB_TRANSP);
    USB->DEVICE.PADCAL.bit.TRIM   = NVM_READ_CAL(NVM_USB_TRIM);

    memset((uint8_t *)usb_mem, 0, sizeof(usb_mem));
    USB->DEVICE.DESCADD.reg = (uint32_t)usb_mem;

    USB->DEVICE.CTRLA.bit.MODE = USB_CTRLA_MODE_DEVICE_Val;
    USB->DEVICE.CTRLA.bit.RUNSTDBY = 1;
    USB->DEVICE.CTRLB.bit.SPDCONF = USB_DEVICE_CTRLB_SPDCONF_FS_Val;
    USB->DEVICE.CTRLB.bit.DETACH = 0;

    // Set interrupt enables.
    USB->DEVICE.INTENSET.bit.EORST = 1;
    USB->DEVICE.DeviceEndpoint[0].EPINTENSET.bit.RXSTP = 1;
    USB->DEVICE.DeviceEndpoint[0].EPINTENSET.bit.TRCPT0 = 1;
    USB->DEVICE.DeviceEndpoint[0].EPINTENSET.bit.TRCPT1 = 1;

    USB->DEVICE.CTRLA.reg |= USB_CTRLA_ENABLE;

    for (int i = 0; i < USB_EP_NUM; i++)
    {
        usb_reset_endpoint(i, USB_IN_ENDPOINT);
        usb_reset_endpoint(i, USB_OUT_ENDPOINT);
    }

    NVIC_EnableIRQ(USB_IRQn);
}

//-----------------------------------------------------------------------------
void irq_handler_usb(void)
{
    // EPINTSMRY is the endpoint interrupt summary register.
    // The flag EPINT[n] is set when an interrupt is triggered by the EndPoint n.
    // This bit will be cleared when no interrupts are pending for EndPoint n.
    int epint = USB->DEVICE.EPINTSMRY.reg;
    int flags;

    // EORST (end of reset) triggers as the device is plugged in and signals
    // that the device is ready to be enumerated by the host.
    if (USB->DEVICE.INTFLAG.bit.EORST)
    {
        USB->DEVICE.INTFLAG.reg = USB_DEVICE_INTFLAG_EORST;
        USB->DEVICE.DADD.reg = USB_DEVICE_DADD_ADDEN;

        for (uint8_t i = 0; i < USB_EP_NUM; i++)
        {
            usb_reset_endpoint(i, USB_IN_ENDPOINT);
            usb_reset_endpoint(i, USB_OUT_ENDPOINT);
        }

        USB->DEVICE.DeviceEndpoint[0].EPCFG.reg =
            USB_DEVICE_EPCFG_EPTYPE0(USB_DEVICE_EPCFG_EPTYPE_CONTROL) |
            USB_DEVICE_EPCFG_EPTYPE1(USB_DEVICE_EPCFG_EPTYPE_CONTROL);
        USB->DEVICE.DeviceEndpoint[0].EPSTATUSSET.bit.BK0RDY = 1;
        USB->DEVICE.DeviceEndpoint[0].EPSTATUSCLR.bit.BK1RDY = 1;

        usb_mem[0].in.ADDR.reg = (uint32_t)usb_ctrl_in_buf;
        usb_mem[0].in.PCKSIZE.bit.SIZE = USB_DEVICE_PCKSIZE_SIZE_64;
        usb_mem[0].in.PCKSIZE.bit.BYTE_COUNT = 0;
        usb_mem[0].in.PCKSIZE.bit.MULTI_PACKET_SIZE = 0;

        usb_mem[0].out.ADDR.reg = (uint32_t)usb_ctrl_out_buf;
        usb_mem[0].out.PCKSIZE.bit.SIZE = USB_DEVICE_PCKSIZE_SIZE_64;
        usb_mem[0].out.PCKSIZE.bit.MULTI_PACKET_SIZE = 8;
        usb_mem[0].out.PCKSIZE.bit.BYTE_COUNT = 0;

        USB->DEVICE.DeviceEndpoint[0].EPSTATUSCLR.bit.BK0RDY = 1;
        USB->DEVICE.DeviceEndpoint[0].EPINTENSET.bit.RXSTP = 1;
        USB->DEVICE.DeviceEndpoint[0].EPINTENSET.bit.TRCPT0 = 1;
        USB->DEVICE.DeviceEndpoint[0].EPINTENSET.bit.TRCPT1 = 1;
    }

    // When a USB device receives a setup packet, it triggers the RXSTP (receive setup) event.
    if (USB->DEVICE.DeviceEndpoint[0].EPINTFLAG.bit.RXSTP)
    {
        // Write 1 to clear interrupt flag.
        USB->DEVICE.DeviceEndpoint[0].EPINTFLAG.bit.RXSTP = 1;
        
        uint8_t requestNotHandled = 
            usb_handle_standard_request((usb_request_t *)usb_ctrl_out_buf) &
            usb_handle_hid_request((usb_request_t *)usb_ctrl_out_buf) &
            usb_handle_cdc_request((usb_request_t *)usb_ctrl_out_buf);
        
        // None of the functions handled the USB request.
        if (requestNotHandled == 1)
        {
            usb_control_stall();
        }
        else
        {
            usb_mem[0].out.PCKSIZE.bit.BYTE_COUNT = 0;
            USB->DEVICE.DeviceEndpoint[0].EPSTATUSCLR.bit.BK0RDY = 1;
        }
    }

    for (int i = 0; epint && (i < USB_EP_NUM); i++)
    {
        if ((epint & (1 << i)) == 0)
        {
            continue;
        }

        epint &= ~(1 << i);

        flags = USB->DEVICE.DeviceEndpoint[i].EPINTFLAG.reg;

        if (flags & USB_DEVICE_EPINTFLAG_TRCPT0)
        {
            // Write 1 to clear interrupt flag.
            USB->DEVICE.DeviceEndpoint[i].EPINTFLAG.bit.TRCPT0 = 1;
            USB->DEVICE.DeviceEndpoint[i].EPSTATUSSET.bit.BK0RDY = 1;
            usb_recv_callback(i);
        }

        if (flags & USB_DEVICE_EPINTFLAG_TRCPT1)
        {
            // Write 1 to clear interrupt flag.
            USB->DEVICE.DeviceEndpoint[i].EPINTFLAG.bit.TRCPT1 = 1;
            USB->DEVICE.DeviceEndpoint[i].EPSTATUSCLR.bit.BK1RDY = 1;
            usb_send_callback(i);
        }
    }
}

//-----------------------------------------------------------------------------
uint8_t usb_handle_standard_request(usb_request_t *request)
{
    switch ((request->bRequest << 8) | request->bmRequestType)
    {
        case USB_CMD(IN, DEVICE, STANDARD, GET_DESCRIPTOR):
        {
            uint8_t type = request->wValue >> 8;
            uint8_t index = request->wValue & 0xff;
            uint16_t offset = request->wIndex;
            uint16_t length = request->wLength;

            if (type == USB_DEVICE_DESCRIPTOR)
            {
                length = LIMIT(length, usb_device_descriptor.bLength);
                usb_control_send((uint8_t *)&usb_device_descriptor, length);
            }
            else if (type == USB_DEVICE_QUALIFIER_DESCRIPTOR)
            {
               length = LIMIT(length, usb_device_descriptor.bLength);
               usb_control_send((uint8_t *)&usb_device_qualifier_descriptor, length);
            }
            else if (type == USB_CONFIGURATION_DESCRIPTOR)
            {
                length = LIMIT(length, usb_configuration_hierarchy.configuration.wTotalLength - offset);
                usb_control_send((uint8_t *)(&usb_configuration_hierarchy + offset), length);
            }
            else if (type == USB_STRING_DESCRIPTOR)
            {
                if (index == 0)
                {
                    length = LIMIT(length, usb_string_descriptor_zero.bLength);
                    usb_control_send((uint8_t *)&usb_string_descriptor_zero, length);
                }
                else if (index < USB_STR_COUNT)
                {
                    const char *str = usb_strings[index];
                    int len = strlen(str);
                    int size = len * 2 + 2;
                    alignas(4) uint8_t buf[size];

                    buf[0] = size;
                    buf[1] = USB_STRING_DESCRIPTOR;

                    for (int i = 0; i < len; i++)
                    {
                        buf[2 + i * 2] = str[i];
                        buf[3 + i * 2] = 0;
                    }

                    length = LIMIT(length, size);

                    usb_control_send(buf, length);
                }
                else
                {
                    usb_control_stall();
                }
            }
            else
            {
                usb_control_stall();
            }
        }
        break;

        case USB_CMD(OUT, DEVICE, STANDARD, SET_ADDRESS):
        {
            usb_control_send_zlp();
            usb_set_address(request->wValue);
        }
        break;

        case USB_CMD(OUT, DEVICE, STANDARD, SET_CONFIGURATION):
        {
            usb_config = request->wValue;
            usb_control_send_zlp();

            if (usb_config)
            {
                uint32_t size = usb_configuration_hierarchy.configuration.wTotalLength;
                usb_descriptor_header_t *desc = (usb_descriptor_header_t *)&usb_configuration_hierarchy;

                while (size)
                {
                    if (USB_ENDPOINT_DESCRIPTOR == desc->bDescriptorType)
                    {
                        usb_configure_endpoint((usb_endpoint_descriptor_t *)desc);
                    }
                    size -= desc->bLength;
                    desc = (usb_descriptor_header_t *)((uint8_t *)desc + desc->bLength);
                }
                usb_configuration_callback(usb_config);
            }
        }
        break;

        case USB_CMD(IN, DEVICE, STANDARD, GET_CONFIGURATION):
        {
            uint8_t config = usb_config;
            usb_control_send(&config, sizeof(config));
        }
        break;

        case USB_CMD(IN, DEVICE, STANDARD, GET_STATUS):
        case USB_CMD(IN, INTERFACE, STANDARD, GET_STATUS):
        {
            uint16_t status = 0;
            usb_control_send((uint8_t *)&status, sizeof(status));
        }
        break;

        case USB_CMD(IN, ENDPOINT, STANDARD, GET_STATUS):
        {
            int ep = request->wIndex & USB_INDEX_MASK;
            int dir = request->wIndex & USB_DIRECTION_MASK;
            uint16_t status = 0;

            if (usb_endpoint_configured(ep, dir))
            {
                status = usb_endpoint_get_status(ep, dir);
                usb_control_send((uint8_t *)&status, sizeof(status));
            }
            else
            {
                usb_control_stall();
            }
        }
        break;

        case USB_CMD(OUT, DEVICE, STANDARD, SET_FEATURE):
        {
            usb_control_stall();
        }
        break;

        case USB_CMD(OUT, INTERFACE, STANDARD, SET_FEATURE):
        {
            usb_control_send_zlp();
        }
        break;

        case USB_CMD(OUT, ENDPOINT, STANDARD, SET_FEATURE):
        {
            int ep = request->wIndex & USB_INDEX_MASK;
            int dir = request->wIndex & USB_DIRECTION_MASK;

            if (request->wValue && ep && usb_endpoint_configured(ep, dir) == 0)
            {
                usb_endpoint_set_feature(ep, dir);
                usb_control_send_zlp();
            }
            else
            {
                usb_control_stall();
            }
        }
        break;

        case USB_CMD(OUT, DEVICE, STANDARD, CLEAR_FEATURE):
        {
            usb_control_stall();
        }
        break;

        case USB_CMD(OUT, INTERFACE, STANDARD, CLEAR_FEATURE):
        {
            usb_control_send_zlp();
        }
        break;

        case USB_CMD(OUT, ENDPOINT, STANDARD, CLEAR_FEATURE):
        {
            int ep = request->wIndex & USB_INDEX_MASK;
            int dir = request->wIndex & USB_DIRECTION_MASK;

            if (request->wValue && ep && usb_endpoint_configured(ep, dir) == 0)
            {
                usb_endpoint_clear_feature(ep, dir);
                usb_control_send_zlp();
            }
            else
            {
                usb_control_stall();
            }
        }
        break;

        default:
        {
            // Return 1 if the request was not handled in this function.
            return 1;
        }
        break;
    }
    // Return 0 if the request was handled in this function.
    return 0;
}

//-----------------------------------------------------------------------------
uint8_t usb_handle_hid_request(usb_request_t *request)
{
    switch ((request->bRequest << 8) | request->bmRequestType)
    {
        case USB_CMD(IN, INTERFACE, STANDARD, GET_DESCRIPTOR):
        {
            uint16_t length = LIMIT(request->wLength, sizeof(usb_hid_report_descriptor));
            usb_control_send((uint8_t *)usb_hid_report_descriptor, length);
        }
        break;

        default:
        {
            // Return 1 if the request was not handled in this function.
            return 1;
        }
        break;
    }
    // Return 0 if the request was handled in this function.
    return 0;
}

//-----------------------------------------------------------------------------
uint8_t usb_handle_cdc_request(usb_request_t *request)
{
    uint8_t length = request->wLength;
    switch ((request->bRequest << 8) | request->bmRequestType)
    {
        case USB_CMD(OUT, INTERFACE, CLASS, CDC_SET_LINE_CODING):
        {
            length = LIMIT(length, sizeof(usb_cdc_line_coding_t));
            usb_recv(0, usb_ctrl_out_buf, length, usb_cdc_update_line_coding);
        }
        break;

        case USB_CMD(IN, INTERFACE, CLASS, CDC_GET_LINE_CODING):
        {
            length = LIMIT(length, sizeof(usb_cdc_line_coding_t));
            usb_control_send((uint8_t *)&usb_cdc_line_coding, length);
        }
        break;

        case USB_CMD(OUT, INTERFACE, CLASS, CDC_SET_CONTROL_LINE_STATE):
        {
            // This state was unimplemented in the example
            usb_control_send_zlp();
        }
        break;

        default:
        {
            // Return 1 if the request was not handled in this function.
            return 1;
        }
        break;
    }
    // Return 0 if the request was handled in this function.
    return 0;
}

//-----------------------------------------------------------------------------
void usb_send(int ep, uint8_t *data, int size, void (*callback)(void))
{
    usb_endpoints[ep].in.callback = callback;

    usb_mem[ep].in.ADDR.reg = (uint32_t)data;
    usb_mem[ep].in.PCKSIZE.bit.BYTE_COUNT = size;
    usb_mem[ep].in.PCKSIZE.bit.MULTI_PACKET_SIZE = 0;

    USB->DEVICE.DeviceEndpoint[ep].EPSTATUSSET.bit.BK1RDY = 1;
}

//-----------------------------------------------------------------------------
void usb_recv(int ep, uint8_t *data, int size, void (*callback)(void))
{
    usb_endpoints[ep].out.callback = callback;

    usb_mem[ep].out.ADDR.reg = (uint32_t)data;
    usb_mem[ep].out.PCKSIZE.bit.MULTI_PACKET_SIZE = size;
    usb_mem[ep].out.PCKSIZE.bit.BYTE_COUNT = 0;

    USB->DEVICE.DeviceEndpoint[ep].EPSTATUSCLR.bit.BK0RDY = 1;
}

//-----------------------------------------------------------------------------
void usb_recv_callback(int ep)
{
    if (usb_endpoints[ep].out.callback)
    {
        usb_endpoints[ep].out.callback();
    }
}

//-----------------------------------------------------------------------------
void usb_send_callback(int ep)
{
    if (usb_endpoints[ep].in.callback)
    {
        usb_endpoints[ep].in.callback();
    }
}

//-----------------------------------------------------------------------------
void usb_attach(void)
{
    USB->DEVICE.CTRLB.bit.DETACH = 0;
}

//-----------------------------------------------------------------------------
void usb_detach(void)
{
    USB->DEVICE.CTRLB.bit.DETACH = 1;
}

//-----------------------------------------------------------------------------
void usb_reset_endpoint(int ep, int dir)
{
    if (USB_IN_ENDPOINT == dir)
    {
        USB->DEVICE.DeviceEndpoint[ep].EPCFG.bit.EPTYPE1 = USB_DEVICE_EPCFG_EPTYPE_DISABLED;
    }
    else
    {
        USB->DEVICE.DeviceEndpoint[ep].EPCFG.bit.EPTYPE0 = USB_DEVICE_EPCFG_EPTYPE_DISABLED;
    }
}

//-----------------------------------------------------------------------------
void usb_configure_endpoint(usb_endpoint_descriptor_t *desc)
{
    int ep, dir, type, size;

    ep = desc->bEndpointAddress & USB_INDEX_MASK;
    dir = desc->bEndpointAddress & USB_DIRECTION_MASK;
    type = desc->bmAttributes & 0x03;
    size = desc->wMaxPacketSize & 0x3ff;

    usb_reset_endpoint(ep, dir);

    if (size <= 8)
        size = USB_DEVICE_PCKSIZE_SIZE_8;
    else if (size <= 16)
        size = USB_DEVICE_PCKSIZE_SIZE_16;
    else if (size <= 32)
        size = USB_DEVICE_PCKSIZE_SIZE_32;
    else if (size <= 64)
        size = USB_DEVICE_PCKSIZE_SIZE_64;
    else if (size <= 128)
        size = USB_DEVICE_PCKSIZE_SIZE_128;
    else if (size <= 256)
        size = USB_DEVICE_PCKSIZE_SIZE_256;
    else if (size <= 512)
        size = USB_DEVICE_PCKSIZE_SIZE_512;
    else if (size <= 1023)
        size = USB_DEVICE_PCKSIZE_SIZE_1023;
    else
        while (1);

    if (USB_CONTROL_ENDPOINT == type)
        type = USB_DEVICE_EPCFG_EPTYPE_CONTROL;
    else if (USB_ISOCHRONOUS_ENDPOINT == type)
        type = USB_DEVICE_EPCFG_EPTYPE_ISOCHRONOUS;
    else if (USB_BULK_ENDPOINT == type)
        type = USB_DEVICE_EPCFG_EPTYPE_BULK;
    else
        type = USB_DEVICE_EPCFG_EPTYPE_INTERRUPT;

    if (USB_IN_ENDPOINT == dir)
    {
        USB->DEVICE.DeviceEndpoint[ep].EPCFG.bit.EPTYPE1 = type;
        USB->DEVICE.DeviceEndpoint[ep].EPINTENSET.bit.TRCPT1 = 1;
        USB->DEVICE.DeviceEndpoint[ep].EPSTATUSCLR.bit.DTGLIN = 1;
        USB->DEVICE.DeviceEndpoint[ep].EPSTATUSCLR.bit.BK1RDY = 1;
        usb_mem[ep].in.PCKSIZE.bit.SIZE = size;
    }
    else
    {
        USB->DEVICE.DeviceEndpoint[ep].EPCFG.bit.EPTYPE0 = type;
        USB->DEVICE.DeviceEndpoint[ep].EPINTENSET.bit.TRCPT0 = 1;
        USB->DEVICE.DeviceEndpoint[ep].EPSTATUSCLR.bit.DTGLOUT = 1;
        USB->DEVICE.DeviceEndpoint[ep].EPSTATUSSET.bit.BK0RDY = 1;
        usb_mem[ep].out.PCKSIZE.bit.SIZE = size;
    }
}

//-----------------------------------------------------------------------------
bool usb_endpoint_configured(int ep, int dir)
{
    if (USB_IN_ENDPOINT == dir)
    {
        return (USB_DEVICE_EPCFG_EPTYPE_DISABLED != USB->DEVICE.DeviceEndpoint[ep].EPCFG.bit.EPTYPE1);
    }
    else
    {
        return (USB_DEVICE_EPCFG_EPTYPE_DISABLED != USB->DEVICE.DeviceEndpoint[ep].EPCFG.bit.EPTYPE0);
    }
}

//-----------------------------------------------------------------------------
int usb_endpoint_get_status(int ep, int dir)
{
    if (USB_IN_ENDPOINT == dir)
    {
        return USB->DEVICE.DeviceEndpoint[ep].EPSTATUS.bit.STALLRQ1;
    }
    else
    {
        return USB->DEVICE.DeviceEndpoint[ep].EPSTATUS.bit.STALLRQ0;
    }
}

//-----------------------------------------------------------------------------
void usb_endpoint_set_feature(int ep, int dir)
{
    if (USB_IN_ENDPOINT == dir)
    {
        USB->DEVICE.DeviceEndpoint[ep].EPSTATUSSET.bit.STALLRQ1 = 1;
    }
    else
    {
        USB->DEVICE.DeviceEndpoint[ep].EPSTATUSSET.bit.STALLRQ0 = 1;
    }
}

//-----------------------------------------------------------------------------
void usb_endpoint_clear_feature(int ep, int dir)
{
    if (USB_IN_ENDPOINT == dir)
    {
        if (USB->DEVICE.DeviceEndpoint[ep].EPSTATUS.bit.STALLRQ1)
        {
            USB->DEVICE.DeviceEndpoint[ep].EPSTATUSCLR.bit.STALLRQ1 = 1;

            if (USB->DEVICE.DeviceEndpoint[ep].EPINTFLAG.bit.STALL1)
            {
                USB->DEVICE.DeviceEndpoint[ep].EPINTFLAG.bit.STALL1 = 1;
                USB->DEVICE.DeviceEndpoint[ep].EPSTATUSCLR.bit.DTGLIN = 1;
            }
        }
    }
    else
    {
        if (USB->DEVICE.DeviceEndpoint[ep].EPSTATUS.bit.STALLRQ0)
        {
            USB->DEVICE.DeviceEndpoint[ep].EPSTATUSCLR.bit.STALLRQ0 = 1;

            if (USB->DEVICE.DeviceEndpoint[ep].EPINTFLAG.bit.STALL0)
            {
                USB->DEVICE.DeviceEndpoint[ep].EPINTFLAG.bit.STALL0 = 1;
                USB->DEVICE.DeviceEndpoint[ep].EPSTATUSCLR.bit.DTGLOUT = 1;
            }
        }
    }
}

//-----------------------------------------------------------------------------
void usb_set_address(int address)
{
    USB->DEVICE.DADD.reg = USB_DEVICE_DADD_ADDEN | USB_DEVICE_DADD_DADD(address);
}

//-----------------------------------------------------------------------------
void usb_control_send_zlp(void)
{
    usb_mem[0].in.PCKSIZE.bit.BYTE_COUNT = 0;
    USB->DEVICE.DeviceEndpoint[0].EPINTFLAG.bit.TRCPT1 = 1;
    USB->DEVICE.DeviceEndpoint[0].EPSTATUSSET.bit.BK1RDY = 1;

    while (USB->DEVICE.DeviceEndpoint[0].EPINTFLAG.bit.TRCPT1 == 0);
}

//-----------------------------------------------------------------------------
void usb_control_stall(void)
{
    USB->DEVICE.DeviceEndpoint[0].EPSTATUSSET.bit.STALLRQ1 = 1;
}

//-----------------------------------------------------------------------------
void usb_control_send(uint8_t *data, int size)
{
    memcpy(usb_ctrl_in_buf, data, size);
    // Must point to an address in RAM, since descriptor information is stored
    // in FLASH, ensure to copy *data into a location in RAM.
    usb_mem[0].in.ADDR.reg = (uint32_t)usb_ctrl_in_buf;

    usb_mem[0].in.PCKSIZE.bit.BYTE_COUNT = size;
    usb_mem[0].in.PCKSIZE.bit.MULTI_PACKET_SIZE = 0;

    USB->DEVICE.DeviceEndpoint[0].EPINTFLAG.bit.TRCPT1 = 1;
    USB->DEVICE.DeviceEndpoint[0].EPSTATUSSET.bit.BK1RDY = 1;

    while (USB->DEVICE.DeviceEndpoint[0].EPINTFLAG.bit.TRCPT1 == 0);
}

//-----------------------------------------------------------------------------
void usb_send_usart_packet(void)
{
    // If there is valid data that was received in the last timer period,
    // then transmit it via the USB.
    if (usart_buf_idx > 0)
    {
        // Copy the data from the first half of the buffer into the second half of the buffer,
        // and send the second half. While sending the second half, the first half may be overwritten
        // without corrupting the data in the second half. This is called "double-buffering".
        // Only copy the memory that was changed, not the entire buffer each time.
        memcpy(&usart_recv_buf[USB_BUFFER_SIZE], &usart_recv_buf[0], usart_buf_idx);

        // Send the data in the second half of the buffer.
        usb_send(USB_CDC_EP_SEND, &usart_recv_buf[USB_BUFFER_SIZE], usart_buf_idx, usb_cdc_send_callback);

        // Set the index to 0 so that the next time a character is received it will overwrite
        // the first half of the buffer.
        usart_buf_idx = 0;
    }
}