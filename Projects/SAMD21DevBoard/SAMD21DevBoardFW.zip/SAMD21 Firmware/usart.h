/*- Guard -------------------------------------------------------------------*/
#ifndef _USART_H_
#define _USART_H_

/*- Includes ----------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdalign.h>

#include "samd21.h"

#include "tc3.h"
#include "util.h"

/*- Definitions -------------------------------------------------------------*/

/*- Types -------------------------------------------------------------------*/

/*- Macros ------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/
extern uint8_t usart_recv_buf[2 * USB_BUFFER_SIZE];
extern uint8_t usart_buf_idx;

/*- Prototypes --------------------------------------------------------------*/
void usart_init(uint32_t baudRate);
void usart_set_baud(uint32_t baud);

#endif  // _USART_H_
