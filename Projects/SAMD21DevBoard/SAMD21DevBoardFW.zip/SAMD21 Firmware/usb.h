/*- Guard -------------------------------------------------------------------*/
#ifndef _USB_H_
#define _USB_H_

/*- Includes ----------------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdalign.h>

#include "samd21.h"

#include "dap_config.h"
#include "dap.h"
#include "dmac.h"
#include "hal_gpio.h"
#include "nvm_data.h"
#include "usart.h"
#include "usb_descriptors.h"
#include "util.h"

/*- Definitions -------------------------------------------------------------*/
#define USB_EP_NUM              8
#define APP_EP_SEND             1
#define APP_EP_RECV             2

/*- Types -------------------------------------------------------------------*/
typedef struct PACK
{
  uint8_t   bmRequestType;
  uint8_t   bRequest;
  uint16_t  wValue;
  uint16_t  wIndex;
  uint16_t  wLength;
} usb_request_t;

typedef struct PACK
{
  uint32_t  dwDTERate;
  uint8_t   bCharFormat;
  uint8_t   bParityType;
  uint8_t   bDataBits;
} usb_cdc_line_coding_t;

typedef struct PACK
{
  usb_request_t request;
  uint16_t      value;
} usb_cdc_notify_serial_state_t;

typedef void (*usb_ep_callback_t)(int size);

/*- Macros ------------------------------------------------------------------*/

/*- Constants ---------------------------------------------------------------*/

/*- Variables ---------------------------------------------------------------*/

/*- Prototypes --------------------------------------------------------------*/
void usb_init(void);
void usb_send(int ep, uint8_t *data, int size, void (*callback)(void));
void usb_recv(int ep, uint8_t *data, int size, void (*callback)(void));
uint8_t usb_handle_standard_request(usb_request_t *request);
uint8_t usb_handle_hid_request(usb_request_t *request);
uint8_t usb_handle_cdc_request(usb_request_t *request);

void usb_configuration_callback(int config);

void usb_send_callback(int ep);
void usb_recv_callback(int ep);

void usb_cdc_send_callback(void);
void usb_cdc_recv_callback(void);
void usb_cdc_comm_callback(void);

void usb_init(void);
void usb_attach(void);
void usb_detach(void);
void usb_reset_endpoint(int ep, int dir);
void usb_configure_endpoint(usb_endpoint_descriptor_t *ep_desc);
bool usb_endpoint_configured(int ep, int dir);
int usb_endpoint_get_status(int ep, int dir);
void usb_endpoint_set_feature(int ep, int dir);
void usb_endpoint_clear_feature(int ep, int dir);
void usb_set_address(int address);
void usb_control_send_zlp(void);
void usb_control_stall(void);
void usb_control_send(uint8_t *data, int size);
void usb_send_usart_packet(void);

#endif // _USB_H_
